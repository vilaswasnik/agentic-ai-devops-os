# AWS Access Key Creation Guide

## What You're Seeing in AWS Console

You're currently in the IAM console creating access keys for user "vilsy". Here's exactly what to do:

### Step 1: Select Use Case
- Choose: **"Local code"**
- Reason: Your Node.js app runs locally and needs AWS access

### Step 2: Set Description (Optional)
- Description: "UCD AI Agent - Bedrock Access"
- This helps you remember what this key is for

### Step 3: Create and Download
1. Click "Create access key"
2. You'll see:
   - Access key ID (starts with AKIA...)
   - Secret access key (long string)
3. **CRITICAL**: Click "Download .csv file" or copy both values
4. You cannot see the secret key again after this page!

### Step 4: Update Your .env File
Replace the placeholders in your .env file with the real values:

```bash
# Before:
AWS_ACCESS_KEY_ID=your_actual_access_key_here
AWS_SECRET_ACCESS_KEY=your_actual_secret_key_here

# After (example - use your actual values):
AWS_ACCESS_KEY_ID=AKIA2ABCDEFGHIJKLMNO
AWS_SECRET_ACCESS_KEY=1234567890abcdefghijklmnopqrstuvwxyzABCD
```

### Security Notes:
- Never share these keys
- Never commit them to git
- Store them securely
- Consider rotating them regularly

## Next Steps After Getting Keys:
1. Enable Bedrock models (Claude 3 Haiku)
2. Test your application
3. Verify everything works

Continue with the AWS console to complete the key creation!
