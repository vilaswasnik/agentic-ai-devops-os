Removed blockchain agent components on request:

Deleted endpoint /api/blockchain/intent from server.js.
Suggested to delete the following files (manual confirmation recommended if needed later):
- public/blockchain-agent.html
- public/scripts/blockchainAgent.js
- Any menu entries referencing /blockchain-agent.html (already removed from copilot.html)
- Links in os.html (to be cleaned next if required)
